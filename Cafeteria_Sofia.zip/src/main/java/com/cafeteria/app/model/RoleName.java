package com.cafeteria.app.model;

public enum RoleName {
    ADMIN,
    CUSTOMER,
    GUEST;
}
