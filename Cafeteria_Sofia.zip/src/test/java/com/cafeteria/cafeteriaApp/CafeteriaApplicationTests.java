package com.cafeteria.cafeteriaApp;

import com.cafeteria.app.CafeteriaApplication;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = CafeteriaApplication.class)
public class CafeteriaApplicationTests {

    @Test
    void contextLoads() {
    }
}
